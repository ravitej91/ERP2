<?php
if(!isset($_POST['sldate']))
{
	die();
}
include "../connect/connects.php";
$sldate = $_POST['sldate'];
$sl = explode("-",$sldate);
$day = $sl[0];
$month = $sl[1];
$year = $sl[2];
$mytime = date("d-M-Y", mktime(0, 0, 0, $month, $day, $year));
echo $mytime;
$temp = mysql_query("SELECT `accid`,`stu_roll`,`total`,`payopt` from receipt WHERE `date` = '$mytime'");
					echo "<table class='table table-bordered'>
					<tr>
					<thead>
					<th>#</th>
					<th>Account Id</th>
					<th>Student Roll</th>
					<th>Total</th>
					<th>DD / Cash</th>
					</thead></tr>";
					$i=1;
					while($row = mysql_fetch_array($temp))
					{
						echo "<tr><td>".$i."</td><td>".$row['accid']."</td><td>".$row['stu_roll']."</td><td>".$row['total']."</td><td>".$row['payopt']."</td></tr>";
						$i = $i+1;
					}
					echo "</table>";
?>