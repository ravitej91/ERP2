<div class="conatiner-fluid">
		<div class="row-fluid">
			<div class="span3 well">
				<ul class="nav nav-list">
					 <li class="nav-header">REPORT</li>
					 <li class="active"><a href="index.php"><i class="icon-home icon-white"></i>Home</a></li>
						<li ><a href="dayoprtns.php"><i class="icon-list"></i>Transactions</a></li>
						<li><a href="branchdet.php"><i class="icon-search"></i>By Branch</a></li>
						<li><a href="stuacc.php"><i class="icon-user"></i>Student Account</a></li>
						<li><a href="logout.php"><i class="icon-lock"></i>Budget</a></li>
						<li class="divider"></li>
						<li class="nav-header">CAMPAIGN</li>
						<li><a href="edit.php"><i class="icon-pencil"></i>Intimation</a></li>
						<li><a href="edit.php"><i class="icon-pencil"></i>Sms to Student</a></li>
						<li><a href="#"><i class="icon-repeat"></i>Intimation Mail</a></li>
						<li><a href="edit.php"><i class="icon-pencil"></i>Sms Records</a></li>
						<li class="divider"></li>
						<li class="nav-header">SITE OPERATIONS</li>
						<li><a href="edit.php"><i class="icon-pencil"></i>OTP Check</a></li>
						<li><a href="edit.php"><i class="icon-pencil"></i>Student Status</a></li>
						<li><a href="edit.php"><i class="icon-pencil"></i>Recieved Payments</a></li>

					</ul>
			</div>