<?php
if(!isset($_POST['branch']))
{
	die();
}
include "../connect/connects.php";
$branch = $_POST['branch'];
$feetype = $_POST['feetype'];
$accyr = $_POST['accyr'];
$payopt = $_POST['payopt'];
$batch = $_POST['batch'];
//echo $accyr;
//echo $feetype;
if($accyr === "First Year")
$table = "stud1";
else if($accyr === "Second Year")
$table = "stud2";
else if($accyr === "Third Year")
$table = "stud3";
else
$table = "stud4";
if($payopt === "Not paid" )
$payopt = 0;
if($feetype === "JNTU")
{
$feetype = "jntu";
$date = "jdate";
}
else if($feetype === "PLACEMENT")
{
$feetype = "placement";
$date = "pdate";
}
else if($feetype === "BUS FEE")
{
	$date= "bdate";
$feetype = "bus";
}
else
{
	$date = "tdate";
$feetype = "tutionfee";
}
if($payopt === "Paid")
$temp = mysql_query("SELECT * from $table where `branch` ='$branch' and `batch` = '$batch' and $feetype != 0 ");
else
$temp = mysql_query("SELECT * from $table where `branch` ='$branch' and `batch` = '$batch' and $feetype = 0 ");
echo "<table class='table table-bordered'>
					<tr>
					<thead>
					<th>#</th>
					<th>ACCID</th>
					<th>Roll Number</th>
					<th>NAME</th>
					<th>Date</th>
					</thead></tr>";
					$i=1;
					while($row = mysql_fetch_array($temp))
					{
						echo "<tr><td>".$i."</td><td>".$row['accid']."</td><td>".$row['stu_roll']."</td><td>".$row['stu_name']."</td><td>".$row[$date]."</td></tr>";
						$i = $i+1;
					}
					echo"</table>";
?>